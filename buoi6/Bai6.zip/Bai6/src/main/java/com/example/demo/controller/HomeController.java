package com.example.demo.controller; 

import java.security.Principal;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

    @GetMapping("/home")
    public String home(Principal principal) {
        // Trả về "Hello, [tên user]" khi truy cập /home
        return "Hello, " + principal.getName();
    }
}